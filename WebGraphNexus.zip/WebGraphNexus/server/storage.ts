import { users, files, type User, type InsertUser, type File, type InsertFile } from "@shared/schema";
import { eq } from "drizzle-orm";
import { db } from "./db";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByWalletAddress(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // File methods
  getFile(id: number): Promise<File | undefined>;
  getFilesByUser(userId: number): Promise<File[]>;
  getFilesByWalletAddress(walletAddress: string): Promise<File[]>;
  createFile(file: InsertFile): Promise<File>;
  deleteFile(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private files: Map<number, File>;
  private userIdCounter: number;
  private fileIdCounter: number;

  constructor() {
    this.users = new Map();
    this.files = new Map();
    this.userIdCounter = 1;
    this.fileIdCounter = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.walletAddress === walletAddress,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: now
    };
    this.users.set(id, user);
    return user;
  }

  // File methods
  async getFile(id: number): Promise<File | undefined> {
    return this.files.get(id);
  }

  async getFilesByUser(userId: number): Promise<File[]> {
    return Array.from(this.files.values()).filter(
      (file) => file.userId === userId
    );
  }

  async getFilesByWalletAddress(walletAddress: string): Promise<File[]> {
    return Array.from(this.files.values()).filter(
      (file) => file.walletAddress === walletAddress
    );
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    const id = this.fileIdCounter++;
    const now = new Date();
    const file: File = {
      ...insertFile,
      id,
      uploadedAt: now
    };
    this.files.set(id, file);
    return file;
  }

  async deleteFile(id: number): Promise<boolean> {
    return this.files.delete(id);
  }
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    if (!db) return undefined;
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
    if (!db) return undefined;
    const [user] = await db.select().from(users).where(eq(users.walletAddress, walletAddress));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    if (!db) throw new Error("Database not initialized");
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // File methods
  async getFile(id: number): Promise<File | undefined> {
    if (!db) return undefined;
    const [file] = await db.select().from(files).where(eq(files.id, id));
    return file;
  }

  async getFilesByUser(userId: number): Promise<File[]> {
    if (!db) return [];
    return await db.select().from(files).where(eq(files.userId, userId));
  }

  async getFilesByWalletAddress(walletAddress: string): Promise<File[]> {
    if (!db) return [];
    return await db.select().from(files).where(eq(files.walletAddress, walletAddress));
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    if (!db) throw new Error("Database not initialized");
    const [file] = await db.insert(files).values(insertFile).returning();
    return file;
  }

  async deleteFile(id: number): Promise<boolean> {
    if (!db) return false;
    const result = await db.delete(files).where(eq(files.id, id)).returning();
    return result.length > 0;
  }
}

// Use DatabaseStorage if DATABASE_URL is provided, otherwise use MemStorage
export const storage = process.env.DATABASE_URL ? new DatabaseStorage() : new MemStorage();
