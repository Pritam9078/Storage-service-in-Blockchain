import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
const { Pool } = pg;

let db: ReturnType<typeof drizzle>;

if (process.env.DATABASE_URL) {
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL
  });
  
  db = drizzle(pool);
} else {
  console.warn("No DATABASE_URL provided. In-memory storage will be used instead.");
}

export { db };
