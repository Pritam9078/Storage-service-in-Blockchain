import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import { z } from "zod";
import { insertUserSchema, insertFileSchema } from "@shared/schema";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = app.route('/api');

  // User endpoints
  app.post('/api/auth', async (req: Request, res: Response) => {
    try {
      const schema = z.object({
        walletAddress: z.string().min(1)
      });

      const result = schema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          error: "Invalid input", 
          details: result.error.format() 
        });
      }

      const { walletAddress } = result.data;
      
      // Check if user exists
      let user = await storage.getUserByWalletAddress(walletAddress);
      
      // If not, create a new user
      if (!user) {
        user = await storage.createUser({
          walletAddress,
          displayName: null,
          email: null
        });
      }

      res.status(200).json({ 
        success: true, 
        user: {
          id: user.id,
          walletAddress: user.walletAddress,
          displayName: user.displayName,
          email: user.email
        } 
      });
    } catch (error) {
      console.error("Auth error:", error);
      res.status(500).json({ error: "Failed to authenticate" });
    }
  });

  // Get user profile
  app.get('/api/user/:walletAddress', async (req: Request, res: Response) => {
    try {
      const { walletAddress } = req.params;
      const user = await storage.getUserByWalletAddress(walletAddress);

      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      res.status(200).json({
        id: user.id,
        walletAddress: user.walletAddress,
        displayName: user.displayName,
        email: user.email
      });
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ error: "Failed to get user data" });
    }
  });

  // Update user profile
  app.patch('/api/user/:walletAddress', async (req: Request, res: Response) => {
    try {
      const { walletAddress } = req.params;
      const schema = z.object({
        displayName: z.string().optional(),
        email: z.string().email().optional()
      });

      const result = schema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          error: "Invalid input", 
          details: result.error.format() 
        });
      }

      const user = await storage.getUserByWalletAddress(walletAddress);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // In a real implementation, we would update the user here
      // Since we're using MemStorage, this is mock functionality
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Update user error:", error);
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  // File endpoints
  // Upload file
  app.post('/api/files', upload.single('file'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const schema = z.object({
        walletAddress: z.string().min(1)
      });

      const result = schema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          error: "Invalid input", 
          details: result.error.format() 
        });
      }

      const { walletAddress } = result.data;
      
      // Check if user exists
      const user = await storage.getUserByWalletAddress(walletAddress);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Convert file to base64
      const fileData = req.file.buffer.toString('base64');
      
      // Create file record
      const file = await storage.createFile({
        userId: user.id,
        walletAddress,
        name: req.file.originalname,
        fileType: req.file.mimetype.split('/')[0], // Extract main type (image, video, etc.)
        fileSize: req.file.size,
        fileData,
        contentType: req.file.mimetype,
        metadata: {
          filename: req.file.originalname,
          size: req.file.size,
          type: req.file.mimetype
        }
      });

      res.status(201).json({
        id: file.id,
        name: file.name,
        fileType: file.fileType,
        fileSize: file.fileSize,
        contentType: file.contentType,
        uploadedAt: file.uploadedAt
      });
    } catch (error) {
      console.error("File upload error:", error);
      res.status(500).json({ error: "Failed to upload file" });
    }
  });

  // Get files for user
  app.get('/api/files/:walletAddress', async (req: Request, res: Response) => {
    try {
      const { walletAddress } = req.params;
      
      // Get files by wallet address
      const files = await storage.getFilesByWalletAddress(walletAddress);

      // Remove file data from response to reduce payload size
      const filesWithoutData = files.map(file => ({
        id: file.id,
        name: file.name,
        fileType: file.fileType,
        fileSize: file.fileSize,
        contentType: file.contentType,
        uploadedAt: file.uploadedAt
      }));

      res.status(200).json(filesWithoutData);
    } catch (error) {
      console.error("Get files error:", error);
      res.status(500).json({ error: "Failed to get files" });
    }
  });

  // Get single file
  app.get('/api/file/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid file ID" });
      }

      const file = await storage.getFile(id);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      res.status(200).json({
        id: file.id,
        userId: file.userId,
        walletAddress: file.walletAddress,
        name: file.name,
        fileType: file.fileType,
        fileSize: file.fileSize,
        fileData: file.fileData,
        contentType: file.contentType,
        uploadedAt: file.uploadedAt,
        metadata: file.metadata
      });
    } catch (error) {
      console.error("Get file error:", error);
      res.status(500).json({ error: "Failed to get file" });
    }
  });

  // Delete file
  app.delete('/api/file/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid file ID" });
      }

      const file = await storage.getFile(id);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      // Simple authorization check
      const schema = z.object({
        walletAddress: z.string().min(1)
      });

      const result = schema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          error: "Invalid input", 
          details: result.error.format() 
        });
      }

      const { walletAddress } = result.data;
      
      // Check if file belongs to user
      if (file.walletAddress !== walletAddress) {
        return res.status(403).json({ error: "Unauthorized" });
      }

      const success = await storage.deleteFile(id);
      if (!success) {
        return res.status(500).json({ error: "Failed to delete file" });
      }

      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Delete file error:", error);
      res.status(500).json({ error: "Failed to delete file" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
