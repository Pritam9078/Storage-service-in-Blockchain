import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import "./styles/animations.css";
import { WalletProvider } from "./context/wallet-context";
import { FileStorageProvider } from "./context/file-storage-context";
import { OverlayProvider } from "./context/overlay-context";

createRoot(document.getElementById("root")!).render(
  <WalletProvider>
    <FileStorageProvider>
      <OverlayProvider>
        <App />
      </OverlayProvider>
    </FileStorageProvider>
  </WalletProvider>
);
