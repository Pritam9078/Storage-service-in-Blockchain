import { ethers } from 'ethers';
import { WalletType } from '@/types/wallet';

export interface WalletProviderRpcError extends Error {
  message: string;
  code: number;
  data?: unknown;
}

class WalletConnector {
  private provider: ethers.providers.Web3Provider | null = null;
  private walletType: WalletType | null = null;

  private getEthereumProvider(): any {
    if (typeof window === 'undefined') return null;
    
    // Check if MetaMask is installed
    if (window.ethereum) {
      return window.ethereum;
    }
    
    return null;
  }

  public async connect(type: WalletType): Promise<string> {
    try {
      this.walletType = type;
      
      const ethereum = this.getEthereumProvider();
      
      if (!ethereum) {
        throw new Error(`No Ethereum provider found. Please install ${type} extension.`);
      }
      
      this.provider = new ethers.providers.Web3Provider(ethereum);
      
      // Request account access
      const accounts = await this.provider.send('eth_requestAccounts', []);
      
      if (accounts && accounts.length > 0) {
        return accounts[0];
      } else {
        throw new Error('No accounts found');
      }
    } catch (error) {
      console.error('Error connecting wallet:', error);
      const e = error as WalletProviderRpcError;
      
      // Handle user rejected request
      if (e.code === 4001) {
        throw new Error('User rejected the connection request');
      }
      
      throw new Error(`Failed to connect to ${type}: ${e.message}`);
    }
  }

  public async getAccounts(): Promise<string[]> {
    if (!this.provider) return [];
    
    try {
      return await this.provider.send('eth_accounts', []);
    } catch (error) {
      console.error('Error getting accounts:', error);
      return [];
    }
  }

  public async getChainId(): Promise<number> {
    if (!this.provider) return 0;
    
    try {
      const chainId = await this.provider.send('eth_chainId', []);
      return parseInt(chainId, 16);
    } catch (error) {
      console.error('Error getting chain ID:', error);
      return 0;
    }
  }

  public async disconnect(): Promise<void> {
    this.provider = null;
    this.walletType = null;
  }

  public formatAddress(address: string): string {
    if (!address) return '';
    if (address.length < 10) return address;
    
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  }

  public getConnectedWalletType(): WalletType | null {
    return this.walletType;
  }

  public isConnected(): boolean {
    return this.provider !== null;
  }
}

// Create singleton instance
const walletConnector = new WalletConnector();

export default walletConnector;
