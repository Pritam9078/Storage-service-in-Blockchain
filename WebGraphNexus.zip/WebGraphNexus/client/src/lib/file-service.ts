import { apiRequest } from '@/lib/queryClient';
import { FileInfo, FileWithData, FileUpload } from '@/types/file';

interface UploadProgress {
  loaded: number;
  total: number;
  percent: number;
}

type ProgressCallback = (progress: UploadProgress) => void;

class FileService {
  async uploadFile(
    file: File, 
    walletAddress: string, 
    onProgress?: ProgressCallback
  ): Promise<FileInfo> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('walletAddress', walletAddress);

    // Use XMLHttpRequest for progress tracking
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      
      // Track progress
      xhr.upload.addEventListener('progress', (event) => {
        if (event.lengthComputable && onProgress) {
          const progress = {
            loaded: event.loaded,
            total: event.total,
            percent: Math.round((event.loaded / event.total) * 100)
          };
          onProgress(progress);
        }
      });
      
      xhr.addEventListener('load', () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const response = JSON.parse(xhr.responseText);
            resolve(response);
          } catch (error) {
            reject(new Error('Invalid response format'));
          }
        } else {
          let errorMessage = 'Upload failed';
          try {
            const response = JSON.parse(xhr.responseText);
            errorMessage = response.error || errorMessage;
          } catch (e) {
            // If parsing fails, use default error message
          }
          reject(new Error(errorMessage));
        }
      });
      
      xhr.addEventListener('error', () => {
        reject(new Error('Network error occurred'));
      });
      
      xhr.addEventListener('abort', () => {
        reject(new Error('Upload aborted'));
      });
      
      xhr.open('POST', '/api/files');
      xhr.send(formData);
    });
  }

  async getFiles(walletAddress: string): Promise<FileInfo[]> {
    const response = await apiRequest('GET', `/api/files/${walletAddress}`);
    return response.json();
  }

  async getFile(fileId: number): Promise<FileWithData> {
    const response = await apiRequest('GET', `/api/file/${fileId}`);
    return response.json();
  }

  async deleteFile(fileId: number, walletAddress: string): Promise<boolean> {
    const response = await apiRequest('DELETE', `/api/file/${fileId}`, { walletAddress });
    const result = await response.json();
    return result.success;
  }
}

const fileService = new FileService();
export default fileService;
