import { useEffect, useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import LoginView from "@/components/login/login-view";
import DashboardView from "@/components/dashboard/dashboard-view";
import { useWallet } from "@/context/wallet-context";
import ConnectionOverlay from "@/components/overlays/connection-overlay";
import UploadProgressOverlay from "@/components/overlays/upload-progress-overlay";
import { useFileStorage } from "@/context/file-storage-context";
import { AnimatePresence } from "framer-motion";
import { useOverlay } from "@/context/overlay-context";

function App() {
  const { wallet, isAuthenticated } = useWallet();
  const { isUploading } = useFileStorage();
  const { isConnectionOverlayOpen, isUploadProgressOverlayOpen } = useOverlay();
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    // Add class to body for global styling
    document.body.classList.add('bg-gray-950');
    
    // Add cyberpunk background to body
    document.body.style.backgroundImage = `
      radial-gradient(circle at 10% 20%, rgba(138, 43, 226, 0.1) 0%, transparent 20%),
      radial-gradient(circle at 90% 80%, rgba(0, 255, 255, 0.1) 0%, transparent 20%),
      linear-gradient(135deg, rgba(20, 20, 31, 0.9) 0%, rgba(13, 13, 19, 0.9) 100%)
    `;
    document.body.style.backgroundAttachment = "fixed";
    
    // Add custom font link
    const linkElement = document.createElement('link');
    linkElement.rel = 'stylesheet';
    linkElement.href = 'https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap';
    document.head.appendChild(linkElement);
    
    // Add font awesome for icons
    const fontAwesome = document.createElement('link');
    fontAwesome.rel = 'stylesheet';
    fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css';
    document.head.appendChild(fontAwesome);
    
    // Add title
    document.title = "OnyxChain - Decentralized Storage";
    
    setIsInitialized(true);

    return () => {
      document.head.removeChild(linkElement);
      document.head.removeChild(fontAwesome);
    };
  }, []);

  if (!isInitialized) {
    return null;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <AnimatePresence mode="wait">
        {isAuthenticated ? <DashboardView key="dashboard" /> : <LoginView key="login" />}
      </AnimatePresence>
      
      {/* Overlays */}
      {isConnectionOverlayOpen && <ConnectionOverlay />}
      {isUploadProgressOverlayOpen && <UploadProgressOverlay />}
      
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
