export interface WalletInfo {
  address: string;
  shortAddress: string;
  chainId?: number;
  isConnected: boolean;
}

export interface WalletUser {
  id?: number;
  walletAddress: string;
  displayName?: string | null;
  email?: string | null;
}

export enum WalletType {
  MetaMask = 'MetaMask',
  WalletConnect = 'WalletConnect',
  CoinbaseWallet = 'CoinbaseWallet'
}
