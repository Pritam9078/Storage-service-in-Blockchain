export interface FileMetadata {
  filename: string;
  size: number;
  type: string;
  [key: string]: any;
}

export interface FileInfo {
  id: number;
  name: string;
  fileType: string;
  fileSize: number;
  contentType: string;
  uploadedAt: string;
  walletAddress?: string;
  metadata?: FileMetadata;
}

export interface FileUpload {
  file: File;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
  error?: string;
}

export interface FileWithData extends FileInfo {
  fileData: string;
}

export type FileTypeCategory = 'image' | 'document' | 'video' | 'audio' | 'archive' | 'code' | 'other';

export const getFileTypeIcon = (fileType: string, contentType?: string): string => {
  if (fileType === 'image') return 'fa-file-image';
  if (fileType === 'video') return 'fa-file-video';
  if (fileType === 'audio') return 'fa-file-audio';
  
  if (contentType) {
    if (contentType.includes('pdf')) return 'fa-file-pdf';
    if (contentType.includes('zip') || contentType.includes('tar') || contentType.includes('rar')) return 'fa-file-archive';
    if (contentType.includes('javascript') || contentType.includes('typescript') || 
        contentType.includes('html') || contentType.includes('css') || 
        contentType.includes('json') || contentType.includes('xml')) return 'fa-file-code';
  }
  
  if (fileType === 'application') {
    if (contentType?.includes('pdf')) return 'fa-file-pdf';
    if (contentType?.includes('msword') || contentType?.includes('document')) return 'fa-file-word';
    if (contentType?.includes('excel') || contentType?.includes('spreadsheet')) return 'fa-file-excel';
    if (contentType?.includes('powerpoint') || contentType?.includes('presentation')) return 'fa-file-powerpoint';
    if (contentType?.includes('zip') || contentType?.includes('tar') || contentType?.includes('rar')) return 'fa-file-archive';
    if (contentType?.includes('code') || contentType?.includes('javascript') || contentType?.includes('typescript')) return 'fa-file-code';
  }
  
  return 'fa-file';
};

export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
};

export const getTimeAgo = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (seconds < 60) return 'Just now';
  
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
  
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} day${days !== 1 ? 's' : ''} ago`;
  
  const weeks = Math.floor(days / 7);
  if (weeks < 4) return `${weeks} week${weeks !== 1 ? 's' : ''} ago`;
  
  const months = Math.floor(days / 30);
  if (months < 12) return `${months} month${months !== 1 ? 's' : ''} ago`;
  
  const years = Math.floor(days / 365);
  return `${years} year${years !== 1 ? 's' : ''} ago`;
};
