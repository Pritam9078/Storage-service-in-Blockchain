import React, { createContext, useState, useEffect, useContext } from 'react';
import walletConnector from '@/lib/wallet-connector';
import { WalletInfo, WalletUser, WalletType } from '@/types/wallet';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface WalletContextType {
  wallet: WalletInfo;
  user: WalletUser | null;
  isConnecting: boolean;
  isAuthenticated: boolean;
  connect: (type: WalletType) => Promise<boolean>;
  disconnect: () => void;
  updateUserProfile: (data: { displayName?: string; email?: string }) => Promise<boolean>;
}

const defaultWallet: WalletInfo = {
  address: '',
  shortAddress: '',
  isConnected: false
};

const WalletContext = createContext<WalletContextType>({
  wallet: defaultWallet,
  user: null,
  isConnecting: false,
  isAuthenticated: false,
  connect: async () => false,
  disconnect: () => {},
  updateUserProfile: async () => false
});

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [wallet, setWallet] = useState<WalletInfo>(defaultWallet);
  const [user, setUser] = useState<WalletUser | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const { toast } = useToast();

  const updateWalletInfo = async () => {
    const accounts = await walletConnector.getAccounts();
    
    if (accounts && accounts.length > 0) {
      const address = accounts[0];
      const shortAddress = walletConnector.formatAddress(address);
      const chainId = await walletConnector.getChainId();
      
      setWallet({
        address,
        shortAddress,
        chainId,
        isConnected: true
      });
      
      return address;
    }
    
    return null;
  };

  const authenticate = async (walletAddress: string) => {
    try {
      const response = await apiRequest('POST', '/api/auth', { walletAddress });
      const data = await response.json();
      
      if (data.success && data.user) {
        setUser(data.user);
        setIsAuthenticated(true);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Authentication error:', error);
      toast({
        title: 'Authentication Error',
        description: 'Failed to authenticate with the server',
        variant: 'destructive'
      });
      return false;
    }
  };

  const connect = async (type: WalletType): Promise<boolean> => {
    setIsConnecting(true);
    
    try {
      const address = await walletConnector.connect(type);
      await updateWalletInfo();
      
      const success = await authenticate(address);
      setIsConnecting(false);
      return success;
    } catch (error) {
      console.error('Connection error:', error);
      setIsConnecting(false);
      
      toast({
        title: 'Wallet Connection Error',
        description: (error as Error).message || 'Failed to connect wallet',
        variant: 'destructive'
      });
      
      return false;
    }
  };

  const disconnect = () => {
    walletConnector.disconnect();
    setWallet(defaultWallet);
    setUser(null);
    setIsAuthenticated(false);
  };

  const updateUserProfile = async (data: { displayName?: string; email?: string }): Promise<boolean> => {
    if (!wallet.address) return false;
    
    try {
      const response = await apiRequest('PATCH', `/api/user/${wallet.address}`, data);
      const result = await response.json();
      
      if (result.success) {
        // Update local user state
        setUser(prev => prev ? { ...prev, ...data } : null);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Update profile error:', error);
      toast({
        title: 'Update Error',
        description: 'Failed to update profile',
        variant: 'destructive'
      });
      return false;
    }
  };

  // Check for existing connection on load
  useEffect(() => {
    const checkConnection = async () => {
      const accounts = await walletConnector.getAccounts();
      
      if (accounts && accounts.length > 0) {
        const address = await updateWalletInfo();
        if (address) {
          await authenticate(address);
        }
      }
    };
    
    checkConnection();
  }, []);

  return (
    <WalletContext.Provider value={{
      wallet,
      user,
      isConnecting,
      isAuthenticated,
      connect,
      disconnect,
      updateUserProfile
    }}>
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = () => useContext(WalletContext);
