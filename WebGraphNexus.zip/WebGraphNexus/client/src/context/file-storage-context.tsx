import React, { createContext, useState, useEffect, useContext } from 'react';
import { FileInfo, FileUpload, formatFileSize } from '@/types/file';
import fileService from '@/lib/file-service';
import { useWallet } from '@/context/wallet-context';
import { useToast } from '@/hooks/use-toast';

interface FileStorageContextType {
  files: FileInfo[];
  recentUploads: FileInfo[];
  isLoading: boolean;
  isUploading: boolean;
  uploadProgress: number;
  currentUploads: FileUpload[];
  uploadFile: (file: File) => Promise<boolean>;
  fetchFiles: () => Promise<void>;
  deleteFile: (fileId: number) => Promise<boolean>;
  cancelUpload: () => void;
}

const FileStorageContext = createContext<FileStorageContextType>({
  files: [],
  recentUploads: [],
  isLoading: false,
  isUploading: false,
  uploadProgress: 0,
  currentUploads: [],
  uploadFile: async () => false,
  fetchFiles: async () => {},
  deleteFile: async () => false,
  cancelUpload: () => {}
});

export const FileStorageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [files, setFiles] = useState<FileInfo[]>([]);
  const [recentUploads, setRecentUploads] = useState<FileInfo[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [currentUploads, setCurrentUploads] = useState<FileUpload[]>([]);
  const { wallet } = useWallet();
  const { toast } = useToast();

  const fetchFiles = async () => {
    if (!wallet.address) return;
    
    setIsLoading(true);
    try {
      const fetchedFiles = await fileService.getFiles(wallet.address);
      setFiles(fetchedFiles);
      
      // Set recent uploads (last 3 files)
      const sortedFiles = [...fetchedFiles].sort((a, b) => 
        new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
      );
      setRecentUploads(sortedFiles.slice(0, 3));
    } catch (error) {
      console.error('Error fetching files:', error);
      toast({
        title: 'Error',
        description: 'Failed to load your files',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const uploadFile = async (file: File): Promise<boolean> => {
    if (!wallet.address) {
      toast({
        title: 'Error',
        description: 'Please connect your wallet first',
        variant: 'destructive'
      });
      return false;
    }
    
    // Create a new upload entry
    const newUpload: FileUpload = {
      file,
      progress: 0,
      status: 'pending'
    };
    
    setCurrentUploads(prev => [...prev, newUpload]);
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      // Update the upload's status
      setCurrentUploads(prev => 
        prev.map(u => u.file === file ? { ...u, status: 'uploading' } : u)
      );
      
      const uploadedFile = await fileService.uploadFile(
        file, 
        wallet.address,
        (progress) => {
          setUploadProgress(progress.percent);
          // Update the specific file's progress
          setCurrentUploads(prev => 
            prev.map(u => u.file === file ? { ...u, progress: progress.percent } : u)
          );
        }
      );
      
      // Update files list with the new file
      setFiles(prev => [uploadedFile, ...prev]);
      setRecentUploads(prev => {
        const updated = [uploadedFile, ...prev].slice(0, 3);
        return updated;
      });
      
      // Update upload status to completed
      setCurrentUploads(prev => 
        prev.map(u => u.file === file ? { ...u, status: 'completed' } : u)
      );
      
      toast({
        title: 'Success',
        description: `${file.name} uploaded successfully`,
      });
      
      return true;
    } catch (error) {
      console.error('Upload error:', error);
      
      // Update upload status to error
      setCurrentUploads(prev => 
        prev.map(u => u.file === file ? { 
          ...u, 
          status: 'error', 
          error: (error as Error).message 
        } : u)
      );
      
      toast({
        title: 'Upload Failed',
        description: (error as Error).message || 'Failed to upload file',
        variant: 'destructive'
      });
      
      return false;
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      
      // Remove completed or error uploads after a delay
      setTimeout(() => {
        setCurrentUploads(prev => 
          prev.filter(u => u.file !== file || u.status === 'uploading' || u.status === 'pending')
        );
      }, 3000);
    }
  };

  const deleteFile = async (fileId: number): Promise<boolean> => {
    if (!wallet.address) return false;
    
    try {
      const success = await fileService.deleteFile(fileId, wallet.address);
      
      if (success) {
        // Remove file from both lists
        setFiles(prev => prev.filter(f => f.id !== fileId));
        setRecentUploads(prev => prev.filter(f => f.id !== fileId));
        
        toast({
          title: 'Success',
          description: 'File deleted successfully',
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Delete error:', error);
      toast({
        title: 'Delete Failed',
        description: (error as Error).message || 'Failed to delete file',
        variant: 'destructive'
      });
      return false;
    }
  };

  const cancelUpload = () => {
    // In a real implementation, this would abort the XMLHttpRequest
    setIsUploading(false);
    setUploadProgress(0);
    
    // Set all uploads in 'uploading' state to 'error' state
    setCurrentUploads(prev => 
      prev.map(u => u.status === 'uploading' ? { 
        ...u, 
        status: 'error', 
        error: 'Upload cancelled' 
      } : u)
    );
    
    toast({
      title: 'Upload Cancelled',
      description: 'The file upload was cancelled',
    });
  };

  // Load files when wallet connects
  useEffect(() => {
    if (wallet.address) {
      fetchFiles();
    } else {
      // Clear files when wallet disconnects
      setFiles([]);
      setRecentUploads([]);
    }
  }, [wallet.address]);

  return (
    <FileStorageContext.Provider value={{
      files,
      recentUploads,
      isLoading,
      isUploading,
      uploadProgress,
      currentUploads,
      uploadFile,
      fetchFiles,
      deleteFile,
      cancelUpload
    }}>
      {children}
    </FileStorageContext.Provider>
  );
};

export const useFileStorage = () => useContext(FileStorageContext);
