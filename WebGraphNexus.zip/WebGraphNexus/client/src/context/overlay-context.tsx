import React, { createContext, useState, useContext } from 'react';

interface OverlayContextType {
  isConnectionOverlayOpen: boolean;
  isUploadProgressOverlayOpen: boolean;
  openConnectionOverlay: () => void;
  closeConnectionOverlay: () => void;
  openUploadProgressOverlay: () => void;
  closeUploadProgressOverlay: () => void;
}

const OverlayContext = createContext<OverlayContextType>({
  isConnectionOverlayOpen: false,
  isUploadProgressOverlayOpen: false,
  openConnectionOverlay: () => {},
  closeConnectionOverlay: () => {},
  openUploadProgressOverlay: () => {},
  closeUploadProgressOverlay: () => {}
});

export const OverlayProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isConnectionOverlayOpen, setIsConnectionOverlayOpen] = useState(false);
  const [isUploadProgressOverlayOpen, setIsUploadProgressOverlayOpen] = useState(false);

  const openConnectionOverlay = () => {
    setIsConnectionOverlayOpen(true);
  };

  const closeConnectionOverlay = () => {
    setIsConnectionOverlayOpen(false);
  };

  const openUploadProgressOverlay = () => {
    setIsUploadProgressOverlayOpen(true);
  };

  const closeUploadProgressOverlay = () => {
    setIsUploadProgressOverlayOpen(false);
  };

  // Subscribe to wallet connection events
  const handleWalletConnect = async () => {
    openConnectionOverlay();
  };

  // Subscribe to file upload events
  const handleFileUpload = () => {
    openUploadProgressOverlay();
  };

  return (
    <OverlayContext.Provider
      value={{
        isConnectionOverlayOpen,
        isUploadProgressOverlayOpen,
        openConnectionOverlay,
        closeConnectionOverlay,
        openUploadProgressOverlay,
        closeUploadProgressOverlay
      }}
    >
      {children}
    </OverlayContext.Provider>
  );
};

export const useOverlay = () => useContext(OverlayContext);
