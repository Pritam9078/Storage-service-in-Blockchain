import { useContext } from 'react';
import { WalletContext } from '@/context/wallet-context';

export const useWallet = () => {
  return useContext(WalletContext);
};
