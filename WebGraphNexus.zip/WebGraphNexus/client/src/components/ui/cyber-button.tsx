import React from 'react';
import { motion } from 'framer-motion';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const buttonVariants = cva(
  "relative overflow-hidden transition-all duration-300 flex items-center justify-center font-medium",
  {
    variants: {
      variant: {
        primary: "bg-gradient-to-r from-gray-900 to-gray-800 hover:from-gray-800 hover:to-gray-900 border border-purple-600",
        secondary: "bg-gradient-to-r from-gray-900 to-gray-800 hover:from-gray-800 hover:to-gray-900 border border-cyan-400",
        destructive: "bg-gradient-to-r from-gray-900 to-gray-800 hover:from-gray-800 hover:to-gray-900 border border-pink-600",
        outline: "bg-transparent border",
        ghost: "border-none bg-transparent hover:bg-gray-900/20"
      },
      size: {
        sm: "py-1 px-3 text-sm",
        md: "py-2 px-4",
        lg: "py-3 px-6 text-lg"
      },
      glow: {
        none: "",
        purple: "hover:shadow-[0_0_15px_rgba(138,43,226,0.5)] hover:border-purple-500",
        cyan: "hover:shadow-[0_0_15px_rgba(0,255,255,0.5)] hover:border-cyan-400",
        pink: "hover:shadow-[0_0_15px_rgba(255,0,255,0.5)] hover:border-pink-500",
      }
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
      glow: "none"
    }
  }
);

export interface CyberButtonProps 
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  children: React.ReactNode;
  hoverGradient?: boolean;
  glitch?: boolean;
  fullWidth?: boolean;
}

const CyberButton = React.forwardRef<HTMLButtonElement, CyberButtonProps>(
  ({ className, variant, size, glow, hoverGradient = true, glitch = false, fullWidth = false, children, ...props }, ref) => {
    return (
      <motion.button
        className={cn(
          buttonVariants({ variant, size, glow }),
          fullWidth && "w-full",
          className
        )}
        ref={ref}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        {...props}
      >
        {hoverGradient && (
          <div className="absolute inset-0 opacity-0 group-hover:opacity-10 bg-gradient-to-r from-purple-600 to-cyan-400 transition-opacity duration-300"></div>
        )}
        
        {glitch && <div className="absolute inset-0 animate-glitch opacity-5"></div>}
        
        <span className="relative z-10">{children}</span>
      </motion.button>
    );
  }
);

CyberButton.displayName = "CyberButton";

export { CyberButton };
