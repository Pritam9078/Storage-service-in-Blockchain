import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { useFileStorage } from '@/context/file-storage-context';
import { formatFileSize, getFileTypeIcon, getTimeAgo, FileInfo } from '@/types/file';
import { HolographicCard, GlowingBlob } from '@/components/decorative-elements';
import { useToast } from '@/hooks/use-toast';

const UploadView: React.FC = () => {
  const { recentUploads, uploadFile, deleteFile } = useFileStorage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      await handleFileUpload(files[0]);
      
      // Reset the input value so the same file can be uploaded again
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleFileUpload = async (file: File) => {
    const maxSizeBytes = 100 * 1024 * 1024; // 100MB
    
    if (file.size > maxSizeBytes) {
      toast({
        title: 'File Too Large',
        description: `Maximum allowed size is 100MB. Your file is ${formatFileSize(file.size)}.`,
        variant: 'destructive'
      });
      return;
    }
    
    try {
      await uploadFile(file);
    } catch (error) {
      console.error('Upload error:', error);
    }
  };

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = async (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
    
    const files = event.dataTransfer.files;
    if (files && files.length > 0) {
      await handleFileUpload(files[0]);
    }
  };

  const handleDeleteFile = async (id: number) => {
    try {
      await deleteFile(id);
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  const viewVariants = {
    initial: { opacity: 0, y: 10 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.3 }
    },
    exit: { 
      opacity: 0,
      y: -10,
      transition: { duration: 0.2 }
    }
  };

  const dropzoneVariants = {
    initial: { 
      borderColor: 'rgba(138, 43, 226, 0.5)',
      backgroundColor: 'rgba(20, 20, 31, 0.7)'
    },
    hover: { 
      borderColor: 'rgba(0, 255, 255, 0.7)',
      backgroundColor: 'rgba(13, 13, 19, 0.7)',
      transition: { duration: 0.2 }
    }
  };

  return (
    <motion.div 
      id="upload-view"
      className="content-view min-h-full p-4 md:p-8 page-transition"
      variants={viewVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-orbitron font-bold mb-1">Upload Files</h1>
        <p className="text-gray-400 mb-8">Store your files securely on OnyxChain</p>
        
        {/* Upload Card */}
        <HolographicCard className="rounded-lg p-6 mb-8 relative overflow-hidden">
          <GlowingBlob 
            color="bg-purple-600" 
            position="-top-20 -right-20" 
            size="w-40 h-40" 
            opacity="opacity-10"
          />
          <GlowingBlob 
            color="bg-cyan-400" 
            position="-bottom-20 -left-20" 
            size="w-40 h-40" 
            opacity="opacity-10"
          />
          
          <div className="text-center p-4">
            <motion.div 
              className={`
                file-input-container mx-auto mb-6 w-full max-w-md h-48 
                border-2 border-dashed rounded-lg flex flex-col items-center justify-center p-4 
                relative overflow-hidden group transition-all cursor-pointer
                ${isDragging ? 'border-cyan-400/70 bg-gray-900/70' : 'border-purple-600/50 bg-gray-900/30'}
              `}
              variants={dropzoneVariants}
              initial="initial"
              animate={isDragging ? "hover" : "initial"}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <input 
                type="file" 
                id="file-upload" 
                ref={fileInputRef}
                multiple 
                className="absolute inset-0 cursor-pointer z-10 opacity-0" 
                onChange={handleFileSelect}
              />
              <div className="pointer-events-none">
                <i className="fas fa-cloud-upload-alt text-4xl mb-3 text-cyan-400 group-hover:text-pink-600 transition-colors duration-300"></i>
                <h3 className="font-orbitron text-lg mb-2">Drop files here or click to upload</h3>
                <p className="text-sm text-gray-400 max-w-xs mx-auto">Upload any file type. Your files are encrypted and stored securely.</p>
              </div>
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/5 to-cyan-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </motion.div>
            
            <div className="text-sm text-gray-400 flex justify-center gap-4 mt-2">
              <span>Maximum size: 100MB</span>
              <span>|</span>
              <span>Supported: All files</span>
            </div>
          </div>
        </HolographicCard>
        
        {/* Recent Uploads */}
        <div>
          <h2 className="text-xl font-orbitron font-bold mb-4 flex items-center">
            <i className="fas fa-history mr-2 text-pink-600"></i>
            Recent Uploads
          </h2>
          
          {recentUploads.length === 0 ? (
            <div className="text-center py-10 text-gray-400">
              <i className="fas fa-inbox text-3xl mb-2 text-purple-600/50"></i>
              <p>No files uploaded yet. Upload your first file to see it here.</p>
            </div>
          ) : (
            <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
              {recentUploads.map((file) => (
                <RecentUploadCard 
                  key={file.id} 
                  file={file} 
                  onDelete={() => handleDeleteFile(file.id)} 
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

interface RecentUploadCardProps {
  file: FileInfo;
  onDelete: () => Promise<void>;
}

const RecentUploadCard: React.FC<RecentUploadCardProps> = ({ file, onDelete }) => {
  const iconClass = getFileTypeIcon(file.fileType, file.contentType);
  
  return (
    <motion.div 
      className="rounded-lg p-4 group"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <HolographicCard className="rounded-lg p-4">
        <div className="flex items-center mb-3">
          <div className="w-10 h-10 rounded bg-gray-950/50 flex items-center justify-center mr-3">
            <i className={`${iconClass} ${file.fileType === 'image' ? 'text-cyan-400' : file.fileType === 'video' ? 'text-green-400' : file.fileType === 'audio' ? 'text-purple-600' : 'text-pink-600'}`}></i>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-medium truncate" title={file.name}>{file.name}</h3>
            <p className="text-xs text-gray-400">{formatFileSize(file.fileSize)} · {getTimeAgo(file.uploadedAt)}</p>
          </div>
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="px-2 py-0.5 rounded-full bg-green-400/20 text-green-400 border border-green-400/30">
            Completed
          </span>
          <div className="flex space-x-2">
            <button className="p-1 hover:text-cyan-400 transition-colors duration-200">
              <i className="fas fa-link"></i>
            </button>
            <button 
              className="p-1 hover:text-pink-600 transition-colors duration-200"
              onClick={onDelete}
            >
              <i className="fas fa-trash-alt"></i>
            </button>
          </div>
        </div>
      </HolographicCard>
    </motion.div>
  );
};

export default UploadView;
