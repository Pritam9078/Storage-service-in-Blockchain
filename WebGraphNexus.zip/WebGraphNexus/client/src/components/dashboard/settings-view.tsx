import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useWallet } from '@/context/wallet-context';
import { HolographicCard, GlowingBlob } from '@/components/decorative-elements';
import { useToast } from '@/hooks/use-toast';

const SettingsView: React.FC = () => {
  const { wallet, user, updateUserProfile } = useWallet();
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [email, setEmail] = useState(user?.email || '');
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  // Toggle states for settings
  const [notifications, setNotifications] = useState(true);
  const [autoSave, setAutoSave] = useState(true);
  const [animations, setAnimations] = useState(true);
  const [privacy, setPrivacy] = useState(false);

  const handleSaveChanges = async () => {
    setIsSaving(true);
    try {
      const success = await updateUserProfile({
        displayName: displayName || null,
        email: email || null
      });
      
      if (success) {
        toast({
          title: 'Success',
          description: 'Your profile has been updated',
        });
      } else {
        toast({
          title: 'Error',
          description: 'Failed to update profile',
          variant: 'destructive'
        });
      }
    } catch (error) {
      console.error('Save error:', error);
      toast({
        title: 'Error',
        description: (error as Error).message || 'Failed to update profile',
        variant: 'destructive'
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleCopyAddress = () => {
    if (wallet.address) {
      navigator.clipboard.writeText(wallet.address);
      toast({
        title: 'Address Copied',
        description: 'Wallet address copied to clipboard',
      });
    }
  };

  const viewVariants = {
    initial: { opacity: 0, y: 10 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.3 }
    },
    exit: { 
      opacity: 0,
      y: -10,
      transition: { duration: 0.2 }
    }
  };

  return (
    <motion.div 
      className="content-view min-h-full p-4 md:p-8"
      variants={viewVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-orbitron font-bold mb-1">Settings</h1>
        <p className="text-gray-400 mb-8">Manage your account preferences</p>
        
        {/* Profile Settings */}
        <HolographicCard className="rounded-lg p-6 mb-8 relative">
          <GlowingBlob 
            color="bg-purple-600" 
            position="-top-20 -right-20" 
            size="w-40 h-40" 
            opacity="opacity-10"
          />
          
          <h2 className="text-xl font-orbitron mb-4">Profile Settings</h2>
          
          <div className="flex flex-col md:flex-row gap-6">
            <div className="flex-shrink-0 flex flex-col items-center">
              <div className="w-32 h-32 rounded-full overflow-hidden border-2 border-cyan-400/40 relative group">
                <div className="w-full h-full bg-gray-800 flex items-center justify-center text-4xl text-white">
                  {(displayName && displayName[0]?.toUpperCase()) || wallet.address.substring(2, 3).toUpperCase()}
                </div>
                <div className="absolute inset-0 bg-gray-950/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <button className="text-cyan-400">
                    <i className="fas fa-camera"></i>
                  </button>
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-2">Click to change avatar</p>
            </div>
            
            <div className="flex-1">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Display Name</label>
                  <input 
                    type="text" 
                    value={displayName} 
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full bg-gray-950/60 border border-purple-600/30 rounded-md py-2 px-3 text-white focus:outline-none focus:border-cyan-400/60"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Email Address</label>
                  <input 
                    type="email" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-gray-950/60 border border-purple-600/30 rounded-md py-2 px-3 text-white focus:outline-none focus:border-cyan-400/60"
                  />
                </div>
                
                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-gray-400 mb-1">Connected Wallet Address</label>
                  <div className="w-full bg-gray-950/60 border border-purple-600/30 rounded-md py-2 px-3 text-white/80 font-mono text-sm flex justify-between items-center">
                    <span>{wallet.address}</span>
                    <button 
                      className="text-cyan-400 hover:text-purple-600 transition-colors duration-200"
                      onClick={handleCopyAddress}
                    >
                      <i className="fas fa-copy"></i>
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="mt-4">
                <button 
                  className="cyber-button py-2 px-4 bg-purple-600/20 hover:bg-purple-600/30 border border-purple-600/50 rounded-md transition-all duration-200 text-purple-600 font-medium disabled:opacity-50"
                  onClick={handleSaveChanges}
                  disabled={isSaving}
                >
                  {isSaving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </div>
          </div>
        </HolographicCard>
        
        {/* Application Settings */}
        <HolographicCard className="rounded-lg p-6 mb-8">
          <h2 className="text-xl font-orbitron mb-4">Application Settings</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Enable Notifications</h3>
                <p className="text-sm text-gray-400">Receive alerts about your account activity</p>
              </div>
              <div className="relative">
                <input 
                  type="checkbox" 
                  id="notifications" 
                  className="sr-only" 
                  checked={notifications}
                  onChange={() => setNotifications(!notifications)}
                />
                <label htmlFor="notifications" className="flex items-center cursor-pointer">
                  <div className={`relative w-12 h-6 ${notifications ? 'bg-purple-600/20' : 'bg-gray-950/60'} rounded-full border ${notifications ? 'border-purple-600/50' : 'border-purple-600/30'} transition-colors duration-300`}>
                    <div className={`dot absolute left-1 top-1 ${notifications ? 'bg-cyan-400' : 'bg-purple-600'} w-4 h-4 rounded-full transition-transform duration-300 transform ${notifications ? 'translate-x-6' : 'translate-x-0'}`}></div>
                  </div>
                </label>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Auto-Save Files</h3>
                <p className="text-sm text-gray-400">Automatically save files when uploaded</p>
              </div>
              <div className="relative">
                <input 
                  type="checkbox" 
                  id="auto-save" 
                  className="sr-only" 
                  checked={autoSave}
                  onChange={() => setAutoSave(!autoSave)}
                />
                <label htmlFor="auto-save" className="flex items-center cursor-pointer">
                  <div className={`relative w-12 h-6 ${autoSave ? 'bg-purple-600/20' : 'bg-gray-950/60'} rounded-full border ${autoSave ? 'border-purple-600/50' : 'border-purple-600/30'} transition-colors duration-300`}>
                    <div className={`dot absolute left-1 top-1 ${autoSave ? 'bg-cyan-400' : 'bg-purple-600'} w-4 h-4 rounded-full transition-transform duration-300 transform ${autoSave ? 'translate-x-6' : 'translate-x-0'}`}></div>
                  </div>
                </label>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Enhanced Animation Effects</h3>
                <p className="text-sm text-gray-400">Show advanced cyberpunk visual effects</p>
              </div>
              <div className="relative">
                <input 
                  type="checkbox" 
                  id="animations" 
                  className="sr-only" 
                  checked={animations}
                  onChange={() => setAnimations(!animations)}
                />
                <label htmlFor="animations" className="flex items-center cursor-pointer">
                  <div className={`relative w-12 h-6 ${animations ? 'bg-purple-600/20' : 'bg-gray-950/60'} rounded-full border ${animations ? 'border-purple-600/50' : 'border-purple-600/30'} transition-colors duration-300`}>
                    <div className={`dot absolute left-1 top-1 ${animations ? 'bg-cyan-400' : 'bg-purple-600'} w-4 h-4 rounded-full transition-transform duration-300 transform ${animations ? 'translate-x-6' : 'translate-x-0'}`}></div>
                  </div>
                </label>
              </div>
            </div>
            
            <div className="pt-4">
              <h3 className="font-medium mb-2">Storage Usage</h3>
              <div className="w-full h-3 bg-gray-950/60 border border-purple-600/30 rounded-full overflow-hidden">
                <div className="h-full w-3/5 bg-gradient-to-r from-purple-600 to-cyan-400 bg-[length:200%_100%] animate-[scan_2s_linear_infinite]"></div>
              </div>
              <div className="flex justify-between text-xs mt-1">
                <span>62.5 MB used</span>
                <span>100 MB total</span>
              </div>
            </div>
          </div>
        </HolographicCard>
        
        {/* Privacy & Security */}
        <HolographicCard className="rounded-lg p-6 mb-8">
          <h2 className="text-xl font-orbitron mb-4">Privacy & Security</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Two-Factor Authentication</h3>
                <p className="text-sm text-gray-400">Add an extra layer of security to your account</p>
              </div>
              <button className="py-1.5 px-3 bg-cyan-400/20 hover:bg-cyan-400/30 border border-cyan-400/50 rounded-md transition-all duration-200 text-cyan-400 font-medium text-sm">
                Enable
              </button>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Privacy Mode</h3>
                <p className="text-sm text-gray-400">Hide your activity from public view</p>
              </div>
              <div className="relative">
                <input 
                  type="checkbox" 
                  id="privacy" 
                  className="sr-only" 
                  checked={privacy}
                  onChange={() => setPrivacy(!privacy)}
                />
                <label htmlFor="privacy" className="flex items-center cursor-pointer">
                  <div className={`relative w-12 h-6 ${privacy ? 'bg-purple-600/20' : 'bg-gray-950/60'} rounded-full border ${privacy ? 'border-purple-600/50' : 'border-purple-600/30'} transition-colors duration-300`}>
                    <div className={`dot absolute left-1 top-1 ${privacy ? 'bg-cyan-400' : 'bg-purple-600'} w-4 h-4 rounded-full transition-transform duration-300 transform ${privacy ? 'translate-x-6' : 'translate-x-0'}`}></div>
                  </div>
                </label>
              </div>
            </div>
            
            <div className="pt-2">
              <button className="cyber-button py-2 px-4 bg-pink-600/20 hover:bg-pink-600/30 border border-pink-600/50 rounded-md transition-all duration-200 text-pink-600 font-medium mt-2">
                Disconnect All Devices
              </button>
            </div>
          </div>
        </HolographicCard>
      </div>
    </motion.div>
  );
};

export default SettingsView;
