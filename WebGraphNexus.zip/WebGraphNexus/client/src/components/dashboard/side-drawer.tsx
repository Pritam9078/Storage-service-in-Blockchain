import React from 'react';
import { motion } from 'framer-motion';
import Logo from '@/components/logo';
import { useWallet } from '@/context/wallet-context';

interface SideDrawerProps {
  isOpen: boolean;
  activeView: 'upload' | 'files' | 'settings';
  onViewChange: (view: 'upload' | 'files' | 'settings') => void;
}

const SideDrawer: React.FC<SideDrawerProps> = ({ 
  isOpen, 
  activeView, 
  onViewChange 
}) => {
  const { wallet, disconnect } = useWallet();

  const drawerVariants = {
    open: { 
      x: 0,
      transition: { 
        type: "spring", 
        stiffness: 300, 
        damping: 30 
      }
    },
    closed: { 
      x: "-100%",
      transition: { 
        type: "spring", 
        stiffness: 300, 
        damping: 30 
      }
    }
  };

  // For larger screens, always show the drawer
  const drawerClass = `
    fixed top-0 left-0 h-full w-64 bg-gray-900 z-30 transform 
    transition-transform duration-300 ease-in-out
    ${isOpen ? 'drawer-active translate-x-0' : 'drawer-inactive -translate-x-full'}
    lg:drawer-active lg:relative lg:translate-x-0
  `;

  return (
    <motion.div 
      className={drawerClass}
      variants={drawerVariants}
      initial={false}
      animate={{ x: isOpen ? 0 : '-100%' }}
    >
      <div className="h-full flex flex-col overflow-hidden border-r border-purple-600/30">
        {/* Logo */}
        <div className="p-4 flex items-center border-b border-purple-600/30">
          <div className="w-8 h-8 mr-3">
            <Logo size="small" animated={false} showText={false} />
          </div>
          <h1 className="font-orbitron text-xl font-bold">ONYX<span className="text-cyan-400">CHAIN</span></h1>
        </div>
        
        {/* Navigation Menu */}
        <nav className="flex-1 py-4 overflow-y-auto">
          <div className="px-4 mb-4">
            <div className="flex items-center px-3 py-2 rounded-md bg-gray-950/50 border border-cyan-400/30">
              <div className="w-8 h-8 rounded-full border border-cyan-400/40 bg-gray-800 flex items-center justify-center text-xs overflow-hidden mr-2">
                {wallet.address.substring(2, 4)}
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="font-mono text-xs text-gray-400">Connected as</p>
                <p className="text-sm font-medium truncate">{wallet.shortAddress}</p>
              </div>
            </div>
          </div>
          
          <div className="space-y-1 px-3">
            <button 
              onClick={() => onViewChange('upload')} 
              className={`nav-btn w-full flex items-center py-2 px-3 rounded-md transition-colors duration-200 hover:bg-gray-950/50 font-medium hover:text-cyan-400 group ${activeView === 'upload' ? 'bg-gray-950/50 text-cyan-400' : ''}`}
            >
              <i className={`fas fa-upload w-5 h-5 mr-3 ${activeView === 'upload' ? 'text-cyan-400' : ''} group-hover:animate-pulse-glow`}></i>
              <span>Upload Files</span>
            </button>
            
            <button 
              onClick={() => onViewChange('files')} 
              className={`nav-btn w-full flex items-center py-2 px-3 rounded-md transition-colors duration-200 hover:bg-gray-950/50 font-medium hover:text-pink-600 group ${activeView === 'files' ? 'bg-gray-950/50 text-pink-600' : ''}`}
            >
              <i className={`fas fa-folder w-5 h-5 mr-3 ${activeView === 'files' ? 'text-pink-600' : ''} group-hover:animate-pulse-glow`}></i>
              <span>My Files</span>
            </button>
            
            <div className="pt-4 mt-4 border-t border-purple-600/20"></div>
            
            <button 
              onClick={() => onViewChange('settings')} 
              className={`nav-btn w-full flex items-center py-2 px-3 rounded-md transition-colors duration-200 hover:bg-gray-950/50 font-medium hover:text-yellow-400 group ${activeView === 'settings' ? 'bg-gray-950/50 text-yellow-400' : ''}`}
            >
              <i className={`fas fa-cog w-5 h-5 mr-3 ${activeView === 'settings' ? 'text-yellow-400' : ''} group-hover:animate-pulse-glow`}></i>
              <span>Settings</span>
            </button>
          </div>
        </nav>
        
        {/* Footer */}
        <div className="p-4 border-t border-purple-600/30">
          <button 
            onClick={disconnect}
            className="w-full flex items-center justify-center py-2 px-3 rounded-md bg-gray-950 hover:bg-gray-900/70 transition-colors duration-200 text-gray-400 hover:text-gray-200"
          >
            <i className="fas fa-power-off w-5 h-5 mr-2 text-pink-600"></i>
            <span>Disconnect</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default SideDrawer;
