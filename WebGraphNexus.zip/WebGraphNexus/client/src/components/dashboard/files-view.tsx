import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useFileStorage } from '@/context/file-storage-context';
import { formatFileSize, getFileTypeIcon, getTimeAgo, FileInfo, FileTypeCategory } from '@/types/file';
import { HolographicCard } from '@/components/decorative-elements';

const FilesView: React.FC = () => {
  const { files, isLoading, deleteFile } = useFileStorage();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<FileTypeCategory | 'all'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const fileCategories: { id: FileTypeCategory | 'all', label: string }[] = [
    { id: 'all', label: 'All Files' },
    { id: 'image', label: 'Images' },
    { id: 'document', label: 'Documents' },
    { id: 'video', label: 'Videos' },
    { id: 'audio', label: 'Audio' },
    { id: 'archive', label: 'Archives' },
    { id: 'code', label: 'Code' }
  ];

  // Filter files based on search term and active category
  const filteredFiles = files.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'all' || file.fileType === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const handleDelete = async (id: number) => {
    try {
      await deleteFile(id);
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  const viewVariants = {
    initial: { opacity: 0, y: 10 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.3 }
    },
    exit: { 
      opacity: 0,
      y: -10,
      transition: { duration: 0.2 }
    }
  };

  return (
    <motion.div 
      className="content-view min-h-full p-4 md:p-8"
      variants={viewVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-orbitron font-bold mb-1">My Files</h1>
            <p className="text-gray-400">All your stored files on OnyxChain</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search files..." 
                className="bg-gray-900 border border-purple-600/30 rounded-md py-2 pl-9 pr-3 w-full sm:w-60 focus:outline-none focus:border-cyan-400/60 text-sm"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
            
            <div className="flex gap-2">
              <button 
                className={`bg-gray-900 border rounded-md p-2 transition-colors duration-200 ${viewMode === 'grid' ? 'border-purple-600/60 text-purple-600' : 'border-purple-600/30 hover:bg-gray-950/60 hover:border-purple-600/60'}`}
                onClick={() => setViewMode('grid')}
              >
                <i className="fas fa-th-large"></i>
              </button>
              <button 
                className={`bg-gray-900 border rounded-md p-2 transition-colors duration-200 ${viewMode === 'list' ? 'border-purple-600/60 text-purple-600' : 'border-purple-600/30 hover:bg-gray-950/60 hover:border-purple-600/60'}`}
                onClick={() => setViewMode('list')}
              >
                <i className="fas fa-list"></i>
              </button>
              <button className="bg-gray-900 border border-purple-600/30 rounded-md p-2 hover:bg-gray-950/60 hover:border-purple-600/60 transition-colors duration-200">
                <i className="fas fa-filter"></i>
              </button>
            </div>
          </div>
        </div>
        
        {/* File Categories */}
        <div className="mb-8 overflow-x-auto scrollbar-hide">
          <div className="flex space-x-2 mb-4 min-w-max">
            {fileCategories.map(category => (
              <button 
                key={category.id}
                className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors duration-200 ${
                  activeCategory === category.id 
                    ? 'bg-purple-600/20 border border-purple-600 text-purple-600' 
                    : 'bg-gray-900 border border-purple-600/30 hover:bg-gray-950/60 hover:border-purple-600/60'
                }`}
                onClick={() => setActiveCategory(category.id)}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
        
        {/* Files Grid/List */}
        {isLoading ? (
          <div className="text-center py-20">
            <div className="w-10 h-10 border-4 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-400">Loading your files...</p>
          </div>
        ) : filteredFiles.length === 0 ? (
          <div className="text-center py-20 text-gray-400">
            <i className="fas fa-folder-open text-5xl mb-4 text-purple-600/50"></i>
            <p className="text-xl mb-2">No files found</p>
            <p>{activeCategory !== 'all' ? `You don't have any ${activeCategory} files.` : searchTerm ? `No files match "${searchTerm}".` : "Upload some files to see them here."}</p>
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredFiles.map(file => (
              <FileGridItem 
                key={file.id} 
                file={file} 
                onDelete={() => handleDelete(file.id)} 
              />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {filteredFiles.map(file => (
              <FileListItem 
                key={file.id} 
                file={file} 
                onDelete={() => handleDelete(file.id)} 
              />
            ))}
          </div>
        )}
        
        {/* Load More Button - only show if there are files */}
        {filteredFiles.length > 0 && (
          <div className="mt-8 text-center">
            <button className="cyber-button bg-gray-900 hover:bg-gray-950 py-2 px-6 rounded-md border border-cyan-400/30 relative group overflow-hidden">
              <div className="absolute inset-0 opacity-0 group-hover:opacity-10 bg-gradient-to-r from-cyan-400 to-purple-600 transition-opacity duration-300"></div>
              <span className="flex items-center justify-center">
                <span>Load More</span>
                <i className="fas fa-spinner ml-2"></i>
              </span>
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
};

interface FileItemProps {
  file: FileInfo;
  onDelete: () => Promise<void>;
}

const FileGridItem: React.FC<FileItemProps> = ({ file, onDelete }) => {
  const iconClass = getFileTypeIcon(file.fileType, file.contentType);
  
  return (
    <motion.div
      className="rounded-lg overflow-hidden group"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <HolographicCard className="rounded-lg overflow-hidden">
        <div className="aspect-w-16 aspect-h-9 bg-gray-950/50 relative">
          <div className="absolute inset-0 flex items-center justify-center">
            <i className={`${iconClass} text-4xl ${file.fileType === 'image' ? 'text-cyan-400' : file.fileType === 'video' ? 'text-green-400' : file.fileType === 'audio' ? 'text-purple-600' : 'text-pink-600'}`}></i>
          </div>
          <div className="absolute inset-0 bg-gradient-to-br from-gray-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <div className="flex space-x-2">
              <button className="w-8 h-8 rounded-full bg-purple-600/20 border border-purple-600/40 flex items-center justify-center hover:bg-purple-600/30 transition-colors duration-200">
                <i className="fas fa-eye text-purple-600"></i>
              </button>
              <button className="w-8 h-8 rounded-full bg-cyan-400/20 border border-cyan-400/40 flex items-center justify-center hover:bg-cyan-400/30 transition-colors duration-200">
                <i className="fas fa-download text-cyan-400"></i>
              </button>
              <button 
                className="w-8 h-8 rounded-full bg-pink-600/20 border border-pink-600/40 flex items-center justify-center hover:bg-pink-600/30 transition-colors duration-200"
                onClick={onDelete}
              >
                <i className="fas fa-trash-alt text-pink-600"></i>
              </button>
            </div>
          </div>
        </div>
        <div className="p-3">
          <h3 className="font-medium text-sm truncate" title={file.name}>{file.name}</h3>
          <div className="flex justify-between items-center mt-1 text-xs text-gray-400">
            <span>{formatFileSize(file.fileSize)}</span>
            <span>{getTimeAgo(file.uploadedAt)}</span>
          </div>
        </div>
      </HolographicCard>
    </motion.div>
  );
};

const FileListItem: React.FC<FileItemProps> = ({ file, onDelete }) => {
  const iconClass = getFileTypeIcon(file.fileType, file.contentType);
  
  return (
    <motion.div
      className="rounded-lg group"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
    >
      <HolographicCard className="rounded-lg p-3">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded bg-gray-950/50 flex items-center justify-center mr-3 flex-shrink-0">
            <i className={`${iconClass} ${file.fileType === 'image' ? 'text-cyan-400' : file.fileType === 'video' ? 'text-green-400' : file.fileType === 'audio' ? 'text-purple-600' : 'text-pink-600'}`}></i>
          </div>
          <div className="flex-1 min-w-0 mr-4">
            <h3 className="font-medium text-sm truncate" title={file.name}>{file.name}</h3>
            <div className="flex text-xs text-gray-400">
              <span className="mr-3">{formatFileSize(file.fileSize)}</span>
              <span>{getTimeAgo(file.uploadedAt)}</span>
            </div>
          </div>
          <div className="flex space-x-2 flex-shrink-0">
            <button className="w-8 h-8 rounded-full bg-purple-600/10 hover:bg-purple-600/20 border border-purple-600/30 flex items-center justify-center transition-colors duration-200">
              <i className="fas fa-eye text-purple-600"></i>
            </button>
            <button className="w-8 h-8 rounded-full bg-cyan-400/10 hover:bg-cyan-400/20 border border-cyan-400/30 flex items-center justify-center transition-colors duration-200">
              <i className="fas fa-download text-cyan-400"></i>
            </button>
            <button 
              className="w-8 h-8 rounded-full bg-pink-600/10 hover:bg-pink-600/20 border border-pink-600/30 flex items-center justify-center transition-colors duration-200"
              onClick={onDelete}
            >
              <i className="fas fa-trash-alt text-pink-600"></i>
            </button>
          </div>
        </div>
      </HolographicCard>
    </motion.div>
  );
};

export default FilesView;
