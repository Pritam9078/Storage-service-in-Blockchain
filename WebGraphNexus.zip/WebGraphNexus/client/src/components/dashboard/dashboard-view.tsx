import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import SideDrawer from '@/components/dashboard/side-drawer';
import UploadView from '@/components/dashboard/upload-view';
import FilesView from '@/components/dashboard/files-view';
import SettingsView from '@/components/dashboard/settings-view';
import { DashboardBackground } from '@/components/decorative-elements';
import { useWallet } from '@/context/wallet-context';

type ViewType = 'upload' | 'files' | 'settings';

const DashboardView: React.FC = () => {
  const [activeView, setActiveView] = useState<ViewType>('upload');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const { wallet } = useWallet();

  const toggleDrawer = () => {
    setDrawerOpen(!drawerOpen);
  };

  const handleViewChange = (view: ViewType) => {
    setActiveView(view);
    // Close drawer on mobile when view changes
    if (drawerOpen) {
      setDrawerOpen(false);
    }
  };

  return (
    <motion.div 
      className="min-h-screen flex relative"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <SideDrawer 
        isOpen={drawerOpen} 
        onViewChange={handleViewChange} 
        activeView={activeView} 
      />
      
      <div className="flex-1 h-screen flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-gray-900 border-b border-purple-600/30 flex items-center justify-between px-4">
          <button 
            className="lg:hidden w-10 h-10 flex items-center justify-center text-cyan-400"
            onClick={toggleDrawer}
          >
            <i className="fas fa-bars"></i>
          </button>
          
          <div className="flex items-center ml-auto">
            <div className="relative mr-2">
              <button className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-900/50 border border-cyan-400/30 text-cyan-400">
                <i className="fas fa-bell"></i>
              </button>
              <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-pink-600"></span>
            </div>
            
            <button className="flex items-center space-x-2 py-1 px-3 rounded-md hover:bg-gray-900/50 transition-colors duration-200">
              <div className="w-6 h-6 rounded-full border border-cyan-400/40 bg-gray-800 flex items-center justify-center text-xs overflow-hidden">
                {wallet.address.substring(2, 4)}
              </div>
              <span className="text-sm font-medium hidden md:inline">
                {wallet.shortAddress}
              </span>
            </button>
          </div>
        </header>
        
        {/* Content Views Container */}
        <div className="flex-1 overflow-auto bg-gray-950 relative">
          <DashboardBackground />
          
          <AnimatePresence mode="wait">
            {activeView === 'upload' && <UploadView key="upload" />}
            {activeView === 'files' && <FilesView key="files" />}
            {activeView === 'settings' && <SettingsView key="settings" />}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
};

export default DashboardView;
