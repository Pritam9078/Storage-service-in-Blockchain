import React from 'react';
import { motion } from 'framer-motion';

interface LogoProps {
  size?: 'small' | 'medium' | 'large';
  animated?: boolean;
  showText?: boolean;
}

const Logo: React.FC<LogoProps> = ({ 
  size = 'medium', 
  animated = true,
  showText = true
}) => {
  const sizes = {
    small: { svg: 'w-8 h-8', text: 'text-xl' },
    medium: { svg: 'w-16 h-16', text: 'text-3xl sm:text-4xl' },
    large: { svg: 'w-24 h-24', text: 'text-4xl sm:text-5xl' }
  };

  const logoVariants = {
    initial: { opacity: 0, scale: 0.8 },
    animate: { 
      opacity: 1, 
      scale: 1,
      transition: { duration: 0.5 }
    }
  };

  const textVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.5, 
        delay: 0.3
      }
    }
  };

  return (
    <div className="flex flex-col items-center">
      <motion.div 
        className={`${animated ? 'animate-pulse-glow' : ''} inline-block`}
        variants={animated ? logoVariants : undefined}
        initial={animated ? "initial" : undefined}
        animate={animated ? "animate" : undefined}
      >
        <svg 
          className={`mx-auto ${sizes[size].svg}`} 
          viewBox="0 0 100 100" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
        >
          <polygon 
            points="50,10 90,30 90,70 50,90 10,70 10,30" 
            fill="url(#logoGradient)" 
            stroke="#00FFFF" 
            strokeWidth="1" 
          />
          <circle 
            cx="50" 
            cy="50" 
            r="15" 
            fill="#0D0D13" 
            stroke="#FF00FF" 
            strokeWidth="1" 
          />
          <path d="M50 35 L50 65" stroke="#00FFFF" strokeWidth="1" />
          <path d="M35 50 L65 50" stroke="#FF00FF" strokeWidth="1" />
          <defs>
            <linearGradient 
              id="logoGradient" 
              x1="0" 
              y1="0" 
              x2="100" 
              y2="100" 
              gradientUnits="userSpaceOnUse"
            >
              <stop offset="0%" stopColor="rgba(138, 43, 226, 0.2)" />
              <stop offset="100%" stopColor="rgba(0, 255, 255, 0.2)" />
            </linearGradient>
          </defs>
        </svg>
      </motion.div>
      
      {showText && (
        <motion.div
          className="text-center mt-4"
          variants={animated ? textVariants : undefined}
          initial={animated ? "initial" : undefined}
          animate={animated ? "animate" : undefined}
        >
          <h1 className={`font-orbitron font-bold ${sizes[size].text} bg-clip-text text-transparent bg-gradient-to-r from-purple-600 via-cyan-400 to-pink-600 ${animated ? 'animate-glitch' : ''}`}>
            ONYX<span className="text-cyan-400">CHAIN</span>
          </h1>
          <p className="text-gray-400 mt-2 font-mono tracking-wider text-sm">
            DECENTRALIZED STORAGE
          </p>
        </motion.div>
      )}
    </div>
  );
};

export default Logo;
