import React from 'react';
import { motion } from 'framer-motion';

export const BackgroundGrid: React.FC = () => {
  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Top right corner element */}
      <div className="absolute top-0 right-0 w-64 h-64">
        <svg viewBox="0 0 100 100" className="w-full h-full opacity-20">
          <circle cx="80" cy="20" r="15" fill="none" stroke="#FF00FF" strokeWidth="0.5" />
          <circle cx="80" cy="20" r="10" fill="none" stroke="#00FFFF" strokeWidth="0.2" />
          <line x1="80" y1="5" x2="80" y2="35" stroke="#FF00FF" strokeWidth="0.2" />
          <line x1="65" y1="20" x2="95" y2="20" stroke="#00FFFF" strokeWidth="0.2" />
        </svg>
      </div>
      
      {/* Bottom left grid element */}
      <div className="absolute bottom-0 left-0 w-64 h-64">
        <svg viewBox="0 0 100 100" className="w-full h-full opacity-20">
          <line x1="0" y1="20" x2="100" y2="20" stroke="#8A2BE2" strokeWidth="0.2" />
          <line x1="0" y1="40" x2="100" y2="40" stroke="#8A2BE2" strokeWidth="0.2" />
          <line x1="0" y1="60" x2="100" y2="60" stroke="#8A2BE2" strokeWidth="0.2" />
          <line x1="0" y1="80" x2="100" y2="80" stroke="#8A2BE2" strokeWidth="0.2" />
          <line x1="20" y1="0" x2="20" y2="100" stroke="#00FFFF" strokeWidth="0.2" />
          <line x1="40" y1="0" x2="40" y2="100" stroke="#00FFFF" strokeWidth="0.2" />
          <line x1="60" y1="0" x2="60" y2="100" stroke="#00FFFF" strokeWidth="0.2" />
          <line x1="80" y1="0" x2="80" y2="100" stroke="#00FFFF" strokeWidth="0.2" />
        </svg>
      </div>
    </div>
  );
};

export const DashboardBackground: React.FC = () => {
  return (
    <div className="absolute inset-0 pointer-events-none">
      <div className="absolute top-10 right-10 w-96 h-96 bg-purple-600 opacity-5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-cyan-400 opacity-5 rounded-full blur-3xl"></div>
      
      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-10">
        <div 
          className="absolute right-0 top-0 h-full w-1/2" 
          style={{
            backgroundImage: "radial-gradient(circle at 2px 2px, rgba(0, 255, 255, 0.1) 2px, transparent 0)",
            backgroundSize: "40px 40px"
          }}
        ></div>
        <div 
          className="absolute left-0 bottom-0 h-1/2 w-1/2" 
          style={{
            backgroundImage: "radial-gradient(circle at 2px 2px, rgba(138, 43, 226, 0.1) 2px, transparent 0)",
            backgroundSize: "40px 40px"
          }}
        ></div>
      </div>
    </div>
  );
};

export const GlowingBlob: React.FC<{
  color: string;
  size?: string;
  position: string;
  opacity?: string;
}> = ({ color, size = 'w-40 h-40', position, opacity = 'opacity-10' }) => {
  return (
    <div className={`absolute ${position} ${size} ${color} ${opacity} rounded-full blur-xl`}></div>
  );
};

export const CyberpunkBorder: React.FC<{ children: React.ReactNode; className?: string }> = ({ 
  children,
  className = ''
}) => {
  return (
    <div className={`cyberpunk-border relative border border-purple-500/50 overflow-hidden ${className}`}>
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-purple-600 to-transparent animate-scan"></div>
      <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-scan-reverse"></div>
      {children}
    </div>
  );
};

export const HolographicCard: React.FC<{ 
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
}> = ({ 
  children,
  className = '',
  hover = true
}) => {
  return (
    <div className={`
      bg-gradient-to-b from-gray-900/70 to-gray-950/70
      backdrop-blur-md 
      border border-purple-500/30 
      ${hover ? 'hover:border-cyan-400/50 transition-all duration-300' : ''}
      ${className}
    `}>
      {children}
    </div>
  );
};

interface AnimatedGradientProps {
  className?: string;
  children: React.ReactNode;
}

export const AnimatedGradient: React.FC<AnimatedGradientProps> = ({ className = '', children }) => {
  return (
    <motion.div 
      className={`bg-gradient-to-r from-purple-600 via-cyan-400 to-purple-600 bg-[length:200%_100%] ${className}`}
      animate={{ 
        backgroundPosition: ['0% center', '100% center', '0% center'],
      }}
      transition={{ 
        duration: 3,
        ease: "linear",
        repeat: Infinity,
      }}
    >
      {children}
    </motion.div>
  );
};
