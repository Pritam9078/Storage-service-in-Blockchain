import React from 'react';
import { motion } from 'framer-motion';
import { HolographicCard, GlowingBlob } from '@/components/decorative-elements';
import { useOverlay } from '@/context/overlay-context';
import { useFileStorage } from '@/context/file-storage-context';
import { formatFileSize } from '@/types/file';

const UploadProgressOverlay: React.FC = () => {
  const { closeUploadProgressOverlay } = useOverlay();
  const { currentUploads, uploadProgress, cancelUpload } = useFileStorage();
  
  // Get the current file being uploaded
  const currentUpload = currentUploads.find(u => u.status === 'uploading');
  const fileName = currentUpload?.file.name || 'File';
  const fileSize = currentUpload?.file.size || 0;
  const uploadedSize = Math.round((fileSize * uploadProgress) / 100);
  
  // Estimate remaining time based on progress
  const remainingTime = uploadProgress > 0 
    ? Math.round((100 - uploadProgress) / uploadProgress * 5) // Simple estimation
    : 0;
  
  const timeText = remainingTime === 1 
    ? '~1 second remaining' 
    : `~${remainingTime} seconds remaining`;

  const overlayVariants = {
    initial: { opacity: 0 },
    animate: { 
      opacity: 1,
      transition: { duration: 0.3 }
    },
    exit: { 
      opacity: 0,
      transition: { duration: 0.3 }
    }
  };

  const cardVariants = {
    initial: { opacity: 0, scale: 0.9 },
    animate: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        duration: 0.3,
        delay: 0.1
      }
    },
    exit: { 
      opacity: 0,
      scale: 0.9,
      transition: { duration: 0.2 }
    }
  };

  const handleCancel = () => {
    cancelUpload();
    closeUploadProgressOverlay();
  };

  return (
    <motion.div 
      className="fixed inset-0 bg-gray-950/80 backdrop-blur-md z-50 flex items-center justify-center"
      variants={overlayVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <motion.div 
        className="max-w-md w-full p-6"
        variants={cardVariants}
      >
        <HolographicCard className="rounded-lg p-6 relative overflow-hidden">
          <GlowingBlob 
            color="bg-purple-600" 
            position="-top-20 -right-20" 
            size="w-40 h-40" 
            opacity="opacity-10"
          />
          <GlowingBlob 
            color="bg-cyan-400" 
            position="-bottom-20 -left-20" 
            size="w-40 h-40" 
            opacity="opacity-10"
          />
          
          <div className="text-center">
            <div className="inline-block animate-pulse-glow mb-4">
              <i className="fas fa-cloud-upload-alt text-4xl text-cyan-400"></i>
            </div>
            
            <h2 className="text-2xl font-orbitron mb-2">Uploading Files</h2>
            <p className="text-gray-400 mb-4">Encrypting and storing your files securely...</p>
            
            <div className="mb-6">
              <div className="flex justify-between text-sm mb-1">
                <span className="truncate max-w-[250px]">{fileName}</span>
                <span>{uploadProgress}%</span>
              </div>
              <div className="w-full h-2 bg-gray-950/60 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-gradient-to-r from-purple-600 to-cyan-400"
                  initial={{ width: "0%" }}
                  animate={{ 
                    width: `${uploadProgress}%`,
                    transition: { duration: 0.3 }
                  }}
                />
              </div>
            </div>
            
            <div className="flex justify-between text-xs text-gray-400 mb-6">
              <span>{formatFileSize(uploadedSize)} / {formatFileSize(fileSize)}</span>
              <span>{uploadProgress < 100 ? timeText : 'Finalizing...'}</span>
            </div>
            
            <button 
              onClick={handleCancel}
              className="cyber-button py-2 px-6 border border-pink-600/50 rounded-md transition-all duration-200 text-pink-600 font-medium"
            >
              Cancel
            </button>
          </div>
        </HolographicCard>
      </motion.div>
    </motion.div>
  );
};

export default UploadProgressOverlay;
