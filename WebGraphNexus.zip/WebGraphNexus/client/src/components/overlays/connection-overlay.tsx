import React from 'react';
import { motion } from 'framer-motion';
import { HolographicCard, GlowingBlob } from '@/components/decorative-elements';
import { useOverlay } from '@/context/overlay-context';
import { useWallet } from '@/context/wallet-context';

const ConnectionOverlay: React.FC = () => {
  const { closeConnectionOverlay } = useOverlay();
  const { isConnecting } = useWallet();

  const overlayVariants = {
    initial: { opacity: 0 },
    animate: { 
      opacity: 1,
      transition: { duration: 0.3 }
    },
    exit: { 
      opacity: 0,
      transition: { duration: 0.3 }
    }
  };

  const cardVariants = {
    initial: { opacity: 0, scale: 0.9 },
    animate: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        duration: 0.3,
        delay: 0.1
      }
    },
    exit: { 
      opacity: 0,
      scale: 0.9,
      transition: { duration: 0.2 }
    }
  };

  return (
    <motion.div 
      className="fixed inset-0 bg-gray-950/80 backdrop-blur-md z-50 flex items-center justify-center"
      variants={overlayVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <motion.div 
        className="max-w-md w-full p-6"
        variants={cardVariants}
      >
        <HolographicCard className="rounded-lg p-6 relative overflow-hidden">
          <GlowingBlob 
            color="bg-purple-600" 
            position="-top-20 -right-20" 
            size="w-40 h-40" 
            opacity="opacity-10"
          />
          <GlowingBlob 
            color="bg-cyan-400" 
            position="-bottom-20 -left-20" 
            size="w-40 h-40" 
            opacity="opacity-10"
          />
          
          <div className="text-center">
            <div className="inline-block animate-pulse-glow mb-4">
              <svg className="w-16 h-16 mx-auto" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <polygon points="50,10 90,30 90,70 50,90 10,70 10,30" fill="url(#connectGradient)" stroke="#00FFFF" strokeWidth="1" />
                <circle cx="50" cy="50" r="15" fill="#0D0D13" stroke="#FF00FF" strokeWidth="1" />
                <defs>
                  <linearGradient id="connectGradient" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stopColor="rgba(138, 43, 226, 0.2)" />
                    <stop offset="100%" stopColor="rgba(0, 255, 255, 0.2)" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
            
            <h2 className="text-2xl font-orbitron mb-2">Connecting Wallet</h2>
            <p className="text-gray-400 mb-6">Establishing secure connection to your Web3 wallet...</p>
            
            <div className="w-full h-2 bg-gray-950/60 rounded-full overflow-hidden mb-6">
              <motion.div 
                className="h-full bg-gradient-to-r from-purple-600 to-cyan-400"
                initial={{ width: "0%" }}
                animate={{ 
                  width: isConnecting ? ["20%", "60%", "90%"] : "100%",
                  transition: {
                    duration: 2,
                    times: [0, 0.6, 1],
                    ease: "easeInOut"
                  }
                }}
              />
            </div>
            
            <p className="text-sm text-gray-400 mb-4">Please confirm connection request in your wallet application</p>
            
            <button 
              onClick={closeConnectionOverlay}
              className="cyber-button py-2 px-6 border border-pink-600/50 rounded-md transition-all duration-200 text-pink-600 font-medium"
            >
              Cancel
            </button>
          </div>
        </HolographicCard>
      </motion.div>
    </motion.div>
  );
};

export default ConnectionOverlay;
