import React from 'react';
import { motion } from 'framer-motion';
import { WalletType } from '@/types/wallet';
import { useWallet } from '@/context/wallet-context';
import { HolographicCard, GlowingBlob } from '@/components/decorative-elements';

interface LoginCardProps {
  className?: string;
}

const LoginCard: React.FC<LoginCardProps> = ({ className = '' }) => {
  const { connect, isConnecting } = useWallet();

  const handleWalletConnect = async (type: WalletType) => {
    try {
      await connect(type);
    } catch (error) {
      console.error('Failed to connect wallet:', error);
    }
  };

  const cardVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5, delay: 0.2 }
    }
  };

  const buttonVariants = {
    initial: { opacity: 0, x: -10 },
    animate: { opacity: 1, x: 0 },
    hover: { 
      scale: 1.02,
      boxShadow: "0 0 10px rgba(138, 43, 226, 0.4)"
    },
    tap: { scale: 0.98 }
  };

  return (
    <motion.div
      className={`cyberpunk-border rounded-lg p-6 mb-8 relative overflow-hidden ${className}`}
      variants={cardVariants}
      initial="initial"
      animate="animate"
    >
      <HolographicCard className="p-6 rounded-lg relative overflow-hidden">
        <GlowingBlob 
          color="bg-purple-600" 
          position="-top-10 -right-10" 
          opacity="opacity-20"
        />
        <GlowingBlob 
          color="bg-cyan-400" 
          position="-bottom-10 -left-10" 
          opacity="opacity-20"
        />
        
        <h2 className="text-2xl font-orbitron mb-6 text-center">Connect Wallet</h2>
        
        <div className="space-y-4">
          <motion.button
            className="cyber-button bg-gradient-to-r from-gray-900 to-gray-800 hover:from-gray-800 hover:to-gray-900 w-full py-3 px-4 rounded-md border border-purple-600 relative overflow-hidden group transition-all duration-300 flex items-center justify-center"
            onClick={() => handleWalletConnect(WalletType.MetaMask)}
            disabled={isConnecting}
            variants={buttonVariants}
            initial="initial"
            animate="animate"
            whileHover="hover"
            whileTap="tap"
            transition={{ delay: 0.3 }}
          >
            <div className="absolute inset-0 opacity-0 group-hover:opacity-10 bg-gradient-to-r from-purple-600 to-cyan-400 transition-opacity duration-300"></div>
            <svg className="w-6 h-6 mr-3" viewBox="0 0 35 33" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M32.9582 1L19.8241 10.7183L22.2665 5.25812L32.9582 1Z" fill="#E2761B" stroke="#E2761B" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2.04688 1L15.0244 10.8235L12.7386 5.25812L2.04688 1Z" fill="#E4761B" stroke="#E4761B" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M28.2151 23.4844L24.7229 28.7984L32.2511 30.8071L34.4055 23.6211L28.2151 23.4844Z" fill="#E4761B" stroke="#E4761B" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M0.609375 23.6211L2.75209 30.8071L10.2804 28.7984L6.78822 23.4844L0.609375 23.6211Z" fill="#E4761B" stroke="#E4761B" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M9.85352 14.802L7.8291 17.9053L15.2994 18.2155L15.0356 10.1729L9.85352 14.802Z" fill="#E4761B" stroke="#E4761B" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M25.1435 14.802L19.8926 10.0676L19.8242 18.2155L27.2818 17.9053L25.1435 14.802Z" fill="#E4761B" stroke="#E4761B" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M10.2803 28.7984L14.8243 26.6445L10.8876 23.6738L10.2803 28.7984Z" fill="#E4761B" stroke="#E4761B" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M20.1816 26.6445L24.7257 28.7984L24.1184 23.6738L20.1816 26.6445Z" fill="#E4761B" stroke="#E4761B" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="font-medium">{isConnecting ? 'Connecting...' : 'Connect with MetaMask'}</span>
          </motion.button>
          
          <motion.button
            className="cyber-button bg-gradient-to-r from-gray-900 to-gray-800 hover:from-gray-800 hover:to-gray-900 w-full py-3 px-4 rounded-md border border-cyan-400 relative overflow-hidden group transition-all duration-300 flex items-center justify-center"
            onClick={() => handleWalletConnect(WalletType.WalletConnect)}
            disabled={isConnecting}
            variants={buttonVariants}
            initial="initial"
            animate="animate"
            whileHover="hover"
            whileTap="tap"
            transition={{ delay: 0.4 }}
          >
            <div className="absolute inset-0 opacity-0 group-hover:opacity-10 bg-gradient-to-r from-cyan-400 to-pink-600 transition-opacity duration-300"></div>
            <svg className="w-6 h-6 mr-3" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9.58818 11.8556C13.5255 7.94003 19.8258 7.94003 23.7632 11.8556L24.3033 12.3918C24.5222 12.6091 24.5222 12.9629 24.3033 13.1802L22.7296 14.7426C22.6201 14.8513 22.4443 14.8513 22.3348 14.7426L21.6045 14.0183C18.8651 11.2958 14.4862 11.2958 11.7468 14.0183L10.9774 14.7816C10.8679 14.8902 10.6921 14.8902 10.5826 14.7816L9.00891 13.2192C8.78998 13.0019 8.78998 12.6481 9.00891 12.4308L9.58818 11.8556ZM27.5936 15.6611L29.0013 17.0575C29.2202 17.2748 29.2202 17.6286 29.0013 17.8459L22.4862 24.3279C22.2673 24.5452 21.9156 24.5452 21.6967 24.3279C21.6967 24.3279 21.6967 24.3279 21.6967 24.3279L17.0686 19.7296C17.0139 19.6752 16.9236 19.6752 16.8689 19.7296C16.8689 19.7296 16.8689 19.7296 16.8689 19.7296L12.2441 24.3279C12.0252 24.5452 11.6735 24.5452 11.4546 24.3279C11.4546 24.3279 11.4546 24.3279 11.4546 24.3279L4.93617 17.8459C4.71724 17.6286 4.71724 17.2748 4.93617 17.0575L6.34384 15.6611C6.56277 15.4438 6.91449 15.4438 7.13342 15.6611L11.7616 20.2594C11.8163 20.3138 11.9066 20.3138 11.9613 20.2594C11.9613 20.2594 11.9613 20.2594 11.9613 20.2594L16.5827 15.6611C16.8016 15.4438 17.1533 15.4438 17.3723 15.6611C17.3723 15.6611 17.3723 15.6611 17.3723 15.6611L22.004 20.2594C22.0587 20.3138 22.149 20.3138 22.2037 20.2594L26.8319 15.6611C27.0508 15.4438 27.4025 15.4438 27.6215 15.6611C27.5946 15.6342 27.5936 15.6611 27.5936 15.6611Z" fill="#3B99FC"/>
            </svg>
            <span className="font-medium">{isConnecting ? 'Connecting...' : 'Connect with WalletConnect'}</span>
          </motion.button>
          
          <motion.button
            className="cyber-button bg-gradient-to-r from-gray-900 to-gray-800 hover:from-gray-800 hover:to-gray-900 w-full py-3 px-4 rounded-md border border-pink-600 relative overflow-hidden group transition-all duration-300 flex items-center justify-center"
            onClick={() => handleWalletConnect(WalletType.CoinbaseWallet)}
            disabled={isConnecting}
            variants={buttonVariants}
            initial="initial"
            animate="animate"
            whileHover="hover"
            whileTap="tap"
            transition={{ delay: 0.5 }}
          >
            <div className="absolute inset-0 opacity-0 group-hover:opacity-10 bg-gradient-to-r from-pink-600 to-green-400 transition-opacity duration-300"></div>
            <svg className="w-6 h-6 mr-3" width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M14 0C21.732 0 28 6.268 28 14C28 21.732 21.732 28 14 28C6.268 28 0 21.732 0 14C0 6.268 6.268 0 14 0Z" fill="#0052FF"/>
              <path d="M14.0367 19.1405C16.8853 19.1405 19.1905 16.8353 19.1905 13.9867C19.1905 11.1381 16.8853 8.83301 14.0367 8.83301C11.1882 8.83301 8.88297 11.1381 8.88297 13.9867C8.88297 16.8353 11.1882 19.1405 14.0367 19.1405Z" fill="white"/>
            </svg>
            <span className="font-medium">{isConnecting ? 'Connecting...' : 'Connect with Coinbase Wallet'}</span>
          </motion.button>
        </div>
      </HolographicCard>
    </motion.div>
  );
};

export default LoginCard;
