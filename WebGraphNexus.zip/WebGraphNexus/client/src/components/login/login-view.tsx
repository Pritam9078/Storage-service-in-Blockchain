import React from 'react';
import { motion } from 'framer-motion';
import Logo from '@/components/logo';
import LoginCard from '@/components/login/login-card';
import FeatureTags from '@/components/feature-tags';
import { BackgroundGrid } from '@/components/decorative-elements';

const LoginView: React.FC = () => {
  return (
    <motion.div
      className="min-h-screen flex flex-col justify-center items-center p-4 page-transition"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div 
        className="animate-float max-w-md w-full"
        initial={{ y: 20 }}
        animate={{ y: 0 }}
        transition={{ 
          duration: 0.8,
          ease: "easeOut" 
        }}
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <Logo size="large" animated={true} />
        </div>
        
        {/* Login Card */}
        <LoginCard className="mb-8" />
        
        {/* Feature Tags */}
        <FeatureTags />
      </motion.div>
      
      {/* Decorative Elements */}
      <BackgroundGrid />
    </motion.div>
  );
};

export default LoginView;
