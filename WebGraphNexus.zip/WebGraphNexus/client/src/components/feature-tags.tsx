import React from 'react';
import { motion } from 'framer-motion';

interface FeatureTagsProps {
  tags?: string[];
  animated?: boolean;
}

const defaultTags = [
  'CYBERSECURE',
  'DECENTRALIZED',
  'WEB3 NATIVE',
  'ENCRYPTED'
];

const FeatureTags: React.FC<FeatureTagsProps> = ({ 
  tags = defaultTags,
  animated = true
}) => {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  // Map tags to colors
  const tagColors = [
    'border-purple-600', 
    'border-cyan-400', 
    'border-pink-600', 
    'border-green-400'
  ];

  return (
    <motion.div 
      className="flex flex-wrap justify-center gap-3 text-xs font-mono"
      variants={animated ? container : undefined}
      initial={animated ? "hidden" : undefined}
      animate={animated ? "show" : undefined}
    >
      {tags.map((tag, index) => (
        <motion.span 
          key={tag}
          className={`px-3 py-1 rounded-full border ${tagColors[index % tagColors.length]} bg-gray-900/30`}
          variants={animated ? item : undefined}
        >
          {tag}
        </motion.span>
      ))}
    </motion.div>
  );
};

export default FeatureTags;
